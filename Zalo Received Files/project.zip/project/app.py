import os
import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
from flask import Flask, request, render_template, redirect, url_for, Blueprint, Response

model = load_model('model/best_mobilenetv2.h5')

class_names = ['Cataract', 'Diabetic Retinopathy', 'Macular Scar', 'Myopia']

# tạo Flask
app = Flask(__name__, static_folder='static')
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg'}

# Hàm xử lý Request

@app.route('/huongdan')
def home():
    return render_template('home.html')
@app.route('/intro')
def intro():
    return render_template('intro.html')

@app.route('/', methods=['GET', 'POST'])
def file():
    # Nếu là POST (gửi file)
    if request.method == "POST":
        # Lấy file gửi lên
        image_file = request.files['image']
        if image_file:
            # Lưu file
            img_path = os.path.join(app.config['UPLOAD_FOLDER'], image_file.filename)
            image_file.save(img_path)
    
            # Convert image to dest size tensor
            # Tiền xử lý ảnh giống lúc train
            img = image.load_img(img_path, target_size=(256, 256))  # tuỳ input size của model
            img_array = image.img_to_array(img)
            img_array = np.expand_dims(img_array, axis=0)
            img_array = img_array / 255.0

            
            # Dự đoán
            prediction = model.predict(img_array)
            class_index = np.argmax(prediction)
            class_label = class_names[class_index]

            # Trả về kết quả
            return render_template('index.html', prediction=class_label, img_path=img_path)
            
    return render_template('index.html')


if __name__ == "__main__":
    app.run(host='0.0.0.0', port='6868', debug=True)

